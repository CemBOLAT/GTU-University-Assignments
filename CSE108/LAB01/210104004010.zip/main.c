#include "util.h"

int main()
{
	part1();
	part2();
	part3();
}
