#ifndef UTIL_H
# define UTIL_H
#include <stdio.h>

void	part1();
void	part2();
void	part3();

#endif
