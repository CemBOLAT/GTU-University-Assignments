#include<stdio.h>

int noOfDigits(int n1,int digit);

int main()
{
  int n1,ctr;
    printf("\n\n count the digits of a given number :\n");
	printf("-----------------------------------------\n");
    printf(" Input  a number : ");
    scanf("%d",&n1);

   ctr = noOfDigits(n1,0);

    printf(" The number of digits in the number is :  %d \n\n",ctr);
    return 0;
}

int noOfDigits(int n1,int digit)
{
     if(n1!=0)
     {
         digit++;
         n1=n1/10;
         noOfDigits(n1,digit);
    }
    else{
        return digit;
    }
    
}